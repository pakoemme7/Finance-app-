const { useState, useMemo, useEffect } = React;
const { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } = Recharts;

const COLORS_EXPENSE = ["#FF6B6B", "#FF8E53", "#FFC300", "#FF6B9D", "#C77DFF"];
const COLORS_INCOME = ["#06D6A0", "#118AB2", "#4CC9F0", "#56CFE1"];

const CATEGORIES_EXPENSE = ["🍔 Cibo", "🏠 Casa", "🚗 Trasporti", "🎬 Svago", "💊 Salute", "👗 Shopping", "📱 Abbonamenti", "📦 Altro"];
const CATEGORIES_INCOME = ["💼 Stipendio", "💰 Freelance", "📈 Investimenti", "🎁 Regalo", "📦 Altro"];

const monthlyData = [
  { month: "Nov", entrate: 2500, uscite: 1800 },
  { month: "Dic", entrate: 3200, uscite: 2400 },
  { month: "Gen", entrate: 2600, uscite: 1950 },
  { month: "Feb", entrate: 2700, uscite: 2100 },
  { month: "Mar", entrate: 2900, uscite: 2050 },
  { month: "Apr", entrate: 3050, uscite: 1275 },
];

const defaultTransactions = [
  { id: 1, type: "income", amount: 2500, category: "💼 Stipendio", note: "Stipendio Aprile", date: "2026-04-01" },
  { id: 2, type: "expense", amount: 850, category: "🏠 Casa", note: "Affitto", date: "2026-04-02" },
  { id: 3, type: "expense", amount: 120, category: "🍔 Cibo", note: "Spesa settimanale", date: "2026-04-05" },
  { id: 4, type: "expense", amount: 45, category: "🚗 Trasporti", note: "Benzina", date: "2026-04-07" },
  { id: 5, type: "income", amount: 400, category: "💰 Freelance", note: "Progetto web", date: "2026-04-10" },
  { id: 6, type: "expense", amount: 60, category: "🎬 Svago", note: "Cinema + cena", date: "2026-04-12" },
  { id: 7, type: "expense", amount: 35, category: "📱 Abbonamenti", note: "Netflix, Spotify", date: "2026-04-15" },
  { id: 8, type: "expense", amount: 90, category: "👗 Shopping", note: "Vestiti", date: "2026-04-18" },
  { id: 9, type: "income", amount: 150, category: "📈 Investimenti", note: "Dividendi", date: "2026-04-20" },
  { id: 10, type: "expense", amount: 75, category: "💊 Salute", note: "Farmacia", date: "2026-04-22" },
];

function App() {
  const [tab, setTab] = useState("dashboard");
  const [transactions, setTransactions] = useState(() => {
    try {
      const saved = localStorage.getItem("finanze_tx");
      return saved ? JSON.parse(saved) : defaultTransactions;
    } catch { return defaultTransactions; }
  });
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ type: "expense", amount: "", category: "", note: "", date: new Date().toISOString().split("T")[0] });
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    try { localStorage.setItem("finanze_tx", JSON.stringify(transactions)); } catch {}
  }, [transactions]);

  const totalIncome = useMemo(() => transactions.filter(t => t.type === "income").reduce((s, t) => s + t.amount, 0), [transactions]);
  const totalExpense = useMemo(() => transactions.filter(t => t.type === "expense").reduce((s, t) => s + t.amount, 0), [transactions]);
  const balance = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? Math.round((balance / totalIncome) * 100) : 0;

  const expenseByCategory = useMemo(() => {
    const map = {};
    transactions.filter(t => t.type === "expense").forEach(t => { map[t.category] = (map[t.category] || 0) + t.amount; });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a,b) => b.value - a.value);
  }, [transactions]);

  const incomeByCategory = useMemo(() => {
    const map = {};
    transactions.filter(t => t.type === "income").forEach(t => { map[t.category] = (map[t.category] || 0) + t.amount; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [transactions]);

  const filtered = useMemo(() => {
    if (filter === "all") return [...transactions].sort((a, b) => new Date(b.date) - new Date(a.date));
    return [...transactions].filter(t => t.type === filter).sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [transactions, filter]);

  const addTransaction = () => {
    if (!form.amount || !form.category) return;
    setTransactions(prev => [...prev, { ...form, id: Date.now(), amount: parseFloat(form.amount) }]);
    setForm({ type: "expense", amount: "", category: "", note: "", date: new Date().toISOString().split("T")[0] });
    setShowForm(false);
  };

  const deleteTransaction = (id) => setTransactions(prev => prev.filter(t => t.id !== id));

  const css = `
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap');
    * { box-sizing: border-box; }
    body { font-family: 'DM Sans', sans-serif; background: #0A0E1A; color: #E8EAF0; }
    .scroll-area { overflow-y: auto; -webkit-overflow-scrolling: touch; }
    .card { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 20px; }
    .pill-btn { border: none; cursor: pointer; border-radius: 50px; font-family: 'DM Sans', sans-serif; font-weight: 600; transition: all 0.2s; }
    .tx-item { display: flex; align-items: center; gap: 12px; padding: 14px 0; border-bottom: 1px solid rgba(255,255,255,0.06); }
    .tx-icon { width: 44px; height: 44px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0; }
    .progress-bar { height: 6px; background: rgba(255,255,255,0.08); border-radius: 3px; overflow: hidden; }
    .progress-fill { height: 100%; border-radius: 3px; }
    .fab { position: fixed; bottom: 85px; right: 20px; width: 56px; height: 56px; border-radius: 50%; background: linear-gradient(135deg, #63B3ED, #4FD1C5); border: none; cursor: pointer; font-size: 28px; color: white; box-shadow: 0 8px 25px rgba(99,179,237,0.4); display: flex; align-items: center; justify-content: center; z-index: 100; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 200; display: flex; align-items: flex-end; }
    .modal { background: #141828; border-radius: 28px 28px 0 0; width: 100%; padding: 28px 24px 48px; border-top: 1px solid rgba(255,255,255,0.1); }
    .type-toggle { display: flex; background: rgba(255,255,255,0.06); border-radius: 12px; padding: 4px; gap: 4px; }
    .type-btn { flex: 1; padding: 10px; border-radius: 9px; font-weight: 600; font-size: 14px; cursor: pointer; border: none; font-family: 'DM Sans', sans-serif; transition: all 0.2s; }
    input, select { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); border-radius: 12px; color: #E8EAF0; font-family: 'DM Sans', sans-serif; font-size: 15px; padding: 12px 16px; width: 100%; outline: none; -webkit-appearance: none; }
    input::placeholder { color: rgba(232,234,240,0.35); }
    select option { background: #1A1F35; color: #E8EAF0; }
  `;

  return React.createElement(React.Fragment, null,
    React.createElement('style', null, css),
    React.createElement('div', {
      style: { fontFamily: "'DM Sans', sans-serif", background: "#0A0E1A", height: "100vh", maxWidth: 430, margin: "0 auto", color: "#E8EAF0", position: "relative", display: "flex", flexDirection: "column" }
    },
      // Header
      React.createElement('div', { style: { padding: "52px 24px 20px", background: "linear-gradient(180deg, rgba(99,179,237,0.08) 0%, transparent 100%)", flexShrink: 0 } },
        React.createElement('div', { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 } },
          React.createElement('div', null,
            React.createElement('p', { style: { fontSize: 12, color: "rgba(232,234,240,0.5)", fontWeight: 500, letterSpacing: "0.06em", textTransform: "uppercase" } }, "Aprile 2026"),
            React.createElement('h1', { style: { fontSize: 22, fontWeight: 700, marginTop: 2 } }, "Il Mio Portafoglio")
          ),
          React.createElement('div', { style: { width: 42, height: 42, borderRadius: 14, background: "linear-gradient(135deg, #63B3ED, #4FD1C5)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 } }, "💎")
        ),
        // Balance card
        React.createElement('div', { style: { background: "linear-gradient(135deg, #1E3A5F 0%, #1A2F4A 100%)", borderRadius: 24, padding: "20px", border: "1px solid rgba(99,179,237,0.2)", position: "relative", overflow: "hidden" } },
          React.createElement('p', { style: { fontSize: 11, color: "rgba(232,234,240,0.5)", letterSpacing: "0.08em", textTransform: "uppercase", fontWeight: 600 } }, "Saldo Totale"),
          React.createElement('p', { style: { fontSize: 36, fontWeight: 700, fontFamily: "'DM Mono', monospace", marginTop: 6, color: balance >= 0 ? "#4FD1C5" : "#FC8181" } },
            `${balance >= 0 ? "+" : ""}€${balance.toLocaleString("it-IT", { minimumFractionDigits: 2 })}`
          ),
          React.createElement('div', { style: { display: "flex", gap: 16, marginTop: 16 } },
            React.createElement('div', null,
              React.createElement('p', { style: { fontSize: 10, color: "rgba(232,234,240,0.45)", fontWeight: 600 } }, "↑ ENTRATE"),
              React.createElement('p', { style: { fontSize: 16, fontWeight: 600, color: "#4FD1C5", fontFamily: "'DM Mono', monospace", marginTop: 3 } }, `€${totalIncome.toLocaleString("it-IT")}`)
            ),
            React.createElement('div', { style: { width: 1, background: "rgba(255,255,255,0.1)" } }),
            React.createElement('div', null,
              React.createElement('p', { style: { fontSize: 10, color: "rgba(232,234,240,0.45)", fontWeight: 600 } }, "↓ USCITE"),
              React.createElement('p', { style: { fontSize: 16, fontWeight: 600, color: "#FC8181", fontFamily: "'DM Mono', monospace", marginTop: 3 } }, `€${totalExpense.toLocaleString("it-IT")}`)
            ),
            React.createElement('div', { style: { width: 1, background: "rgba(255,255,255,0.1)" } }),
            React.createElement('div', null,
              React.createElement('p', { style: { fontSize: 10, color: "rgba(232,234,240,0.45)", fontWeight: 600 } }, "💾 RISPARMIO"),
              React.createElement('p', { style: { fontSize: 16, fontWeight: 600, color: "#63B3ED", fontFamily: "'DM Mono', monospace", marginTop: 3 } }, `${savingsRate}%`)
            )
          )
        )
      ),

      // Tabs
      React.createElement('div', { style: { display: "flex", padding: "0 24px 12px", gap: 6, flexShrink: 0 } },
        [["dashboard", "📊 Dashboard"], ["transactions", "📋 Movimenti"], ["charts", "📈 Grafici"]].map(([key, label]) =>
          React.createElement('button', {
            key, className: "pill-btn",
            onClick: () => setTab(key),
            style: { flex: 1, padding: "9px 4px", fontSize: 11, color: tab === key ? "#0A0E1A" : "rgba(232,234,240,0.5)", background: tab === key ? "linear-gradient(135deg, #63B3ED, #4FD1C5)" : "rgba(255,255,255,0.05)" }
          }, label)
        )
      ),

      // Scrollable content
      React.createElement('div', { className: "scroll-area", style: { flex: 1, padding: "0 24px 100px", overflowY: "auto" } },

        // DASHBOARD
        tab === "dashboard" && React.createElement('div', { style: { display: "flex", flexDirection: "column", gap: 14 } },
          React.createElement('div', { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 } },
            [
              { label: "Transazioni", value: transactions.length, icon: "🔄", color: "#63B3ED" },
              { label: "Tasso risparmio", value: `${savingsRate}%`, icon: "💾", color: "#4FD1C5" },
              { label: "Media uscite/g", value: `€${Math.round(totalExpense / 30)}`, icon: "📉", color: "#FC8181" },
              { label: "Più speso in", value: expenseByCategory[0]?.name.split(" ")[1] || "—", icon: "🏷️", color: "#F6AD55" },
            ].map((s, i) =>
              React.createElement('div', { key: i, className: "card", style: { padding: 16 } },
                React.createElement('div', { style: { display: "flex", justifyContent: "space-between" } },
                  React.createElement('p', { style: { fontSize: 11, color: "rgba(232,234,240,0.45)", fontWeight: 500 } }, s.label),
                  React.createElement('span', { style: { fontSize: 18 } }, s.icon)
                ),
                React.createElement('p', { style: { fontSize: 22, fontWeight: 700, color: s.color, fontFamily: "'DM Mono', monospace", marginTop: 8 } }, s.value)
              )
            )
          ),
          React.createElement('div', { className: "card", style: { padding: 18 } },
            React.createElement('p', { style: { fontSize: 14, fontWeight: 600, marginBottom: 14 } }, "📊 Uscite per categoria"),
            expenseByCategory.slice(0, 5).map((cat, i) =>
              React.createElement('div', { key: i, style: { marginBottom: 12 } },
                React.createElement('div', { style: { display: "flex", justifyContent: "space-between", marginBottom: 6 } },
                  React.createElement('span', { style: { fontSize: 13, color: "rgba(232,234,240,0.75)" } }, cat.name),
                  React.createElement('span', { style: { fontSize: 13, fontFamily: "'DM Mono', monospace", color: COLORS_EXPENSE[i % 5] } }, `€${cat.value}`)
                ),
                React.createElement('div', { className: "progress-bar" },
                  React.createElement('div', { className: "progress-fill", style: { width: `${(cat.value / totalExpense) * 100}%`, background: COLORS_EXPENSE[i % 5] } })
                )
              )
            )
          ),
          React.createElement('div', { className: "card", style: { padding: "18px 18px 4px" } },
            React.createElement('p', { style: { fontSize: 14, fontWeight: 600, marginBottom: 4 } }, "🕐 Ultime transazioni"),
            transactions.slice(-5).reverse().map(t =>
              React.createElement('div', { key: t.id, className: "tx-item" },
                React.createElement('div', { className: "tx-icon", style: { background: t.type === "income" ? "rgba(79,209,197,0.12)" : "rgba(252,129,129,0.12)" } }, t.category.split(" ")[0]),
                React.createElement('div', { style: { flex: 1 } },
                  React.createElement('p', { style: { fontSize: 14, fontWeight: 500 } }, t.note || t.category),
                  React.createElement('p', { style: { fontSize: 12, color: "rgba(232,234,240,0.4)", marginTop: 2 } }, new Date(t.date).toLocaleDateString("it-IT"))
                ),
                React.createElement('p', { style: { fontSize: 15, fontWeight: 700, fontFamily: "'DM Mono', monospace", color: t.type === "income" ? "#4FD1C5" : "#FC8181" } },
                  `${t.type === "income" ? "+" : "-"}€${t.amount}`
                )
              )
            )
          )
        ),

        // TRANSACTIONS
        tab === "transactions" && React.createElement('div', null,
          React.createElement('div', { style: { display: "flex", gap: 8, marginBottom: 16 } },
            [["all", "Tutti"], ["expense", "Uscite"], ["income", "Entrate"]].map(([key, label]) =>
              React.createElement('button', {
                key, className: "pill-btn",
                onClick: () => setFilter(key),
                style: { padding: "8px 14px", fontSize: 12, color: filter === key ? "#0A0E1A" : "rgba(232,234,240,0.5)", background: filter === key ? (key === "expense" ? "#FC8181" : key === "income" ? "#4FD1C5" : "linear-gradient(135deg, #63B3ED, #4FD1C5)") : "rgba(255,255,255,0.06)" }
              }, label)
            )
          ),
          React.createElement('div', { className: "card", style: { padding: "0 16px" } },
            filtered.map(t =>
              React.createElement('div', { key: t.id, className: "tx-item" },
                React.createElement('div', { className: "tx-icon", style: { background: t.type === "income" ? "rgba(79,209,197,0.12)" : "rgba(252,129,129,0.12)" } }, t.category.split(" ")[0]),
                React.createElement('div', { style: { flex: 1 } },
                  React.createElement('p', { style: { fontSize: 14, fontWeight: 500 } }, t.note || t.category),
                  React.createElement('p', { style: { fontSize: 12, color: "rgba(232,234,240,0.4)", marginTop: 2 } }, `${t.category} · ${new Date(t.date).toLocaleDateString("it-IT")}`)
                ),
                React.createElement('div', { style: { display: "flex", alignItems: "center", gap: 10 } },
                  React.createElement('p', { style: { fontSize: 15, fontWeight: 700, fontFamily: "'DM Mono', monospace", color: t.type === "income" ? "#4FD1C5" : "#FC8181" } },
                    `${t.type === "income" ? "+" : "-"}€${t.amount}`
                  ),
                  React.createElement('button', { onClick: () => deleteTransaction(t.id), style: { background: "none", border: "none", cursor: "pointer", fontSize: 16, color: "#FC8181", opacity: 0.5 } }, "✕")
                )
              )
            )
          )
        ),

        // CHARTS
        tab === "charts" && React.createElement('div', { style: { display: "flex", flexDirection: "column", gap: 14 } },
          React.createElement('div', { className: "card", style: { padding: 18 } },
            React.createElement('p', { style: { fontSize: 14, fontWeight: 600, marginBottom: 16 } }, "📊 Entrate vs Uscite (6 mesi)"),
            React.createElement(ResponsiveContainer, { width: "100%", height: 170 },
              React.createElement(BarChart, { data: monthlyData, barGap: 3 },
                React.createElement(XAxis, { dataKey: "month", tick: { fill: "rgba(232,234,240,0.4)", fontSize: 11 }, axisLine: false, tickLine: false }),
                React.createElement(YAxis, { hide: true }),
                React.createElement(Tooltip, { contentStyle: { background: "#1A1F35", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, color: "#E8EAF0", fontSize: 12 }, formatter: (v) => [`€${v}`, ""] }),
                React.createElement(Bar, { dataKey: "entrate", fill: "#4FD1C5", radius: [6,6,0,0] }),
                React.createElement(Bar, { dataKey: "uscite", fill: "#FC8181", radius: [6,6,0,0] })
              )
            ),
            React.createElement('div', { style: { display: "flex", gap: 16, justifyContent: "center", marginTop: 8 } },
              React.createElement('div', { style: { display: "flex", alignItems: "center", gap: 6 } },
                React.createElement('div', { style: { width: 10, height: 10, borderRadius: 2, background: "#4FD1C5" } }),
                React.createElement('span', { style: { fontSize: 12, color: "rgba(232,234,240,0.5)" } }, "Entrate")
              ),
              React.createElement('div', { style: { display: "flex", alignItems: "center", gap: 6 } },
                React.createElement('div', { style: { width: 10, height: 10, borderRadius: 2, background: "#FC8181" } }),
                React.createElement('span', { style: { fontSize: 12, color: "rgba(232,234,240,0.5)" } }, "Uscite")
              )
            )
          ),
          React.createElement('div', { className: "card", style: { padding: 18 } },
            React.createElement('p', { style: { fontSize: 14, fontWeight: 600, marginBottom: 16 } }, "📈 Trend Saldo"),
            React.createElement(ResponsiveContainer, { width: "100%", height: 130 },
              React.createElement(LineChart, { data: monthlyData.map(m => ({ ...m, saldo: m.entrate - m.uscite })) },
                React.createElement(XAxis, { dataKey: "month", tick: { fill: "rgba(232,234,240,0.4)", fontSize: 11 }, axisLine: false, tickLine: false }),
                React.createElement(YAxis, { hide: true }),
                React.createElement(Tooltip, { contentStyle: { background: "#1A1F35", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, color: "#E8EAF0", fontSize: 12 }, formatter: (v) => [`€${v}`, "Saldo"] }),
                React.createElement(Line, { type: "monotone", dataKey: "saldo", stroke: "#63B3ED", strokeWidth: 2.5, dot: { fill: "#63B3ED", r: 4 } })
              )
            )
          ),
          React.createElement('div', { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 } },
            [{ title: "Uscite", data: expenseByCategory, colors: COLORS_EXPENSE }, { title: "Entrate", data: incomeByCategory, colors: COLORS_INCOME }].map((chart, ci) =>
              React.createElement('div', { key: ci, className: "card", style: { padding: 16 } },
                React.createElement('p', { style: { fontSize: 13, fontWeight: 600, marginBottom: 10 } }, chart.title),
                React.createElement(ResponsiveContainer, { width: "100%", height: 90 },
                  React.createElement(PieChart, null,
                    React.createElement(Pie, { data: chart.data, cx: "50%", cy: "50%", innerRadius: 24, outerRadius: 40, dataKey: "value", strokeWidth: 0 },
                      chart.data.map((_, i) => React.createElement(Cell, { key: i, fill: chart.colors[i % chart.colors.length] }))
                    )
                  )
                ),
                chart.data.slice(0, 3).map((d, i) =>
                  React.createElement('div', { key: i, style: { display: "flex", alignItems: "center", gap: 6, marginBottom: 4 } },
                    React.createElement('div', { style: { width: 8, height: 8, borderRadius: "50%", background: chart.colors[i % chart.colors.length], flexShrink: 0 } }),
                    React.createElement('span', { style: { fontSize: 10, color: "rgba(232,234,240,0.5)", flex: 1 } }, d.name.split(" ")[1]),
                    React.createElement('span', { style: { fontSize: 10, fontFamily: "'DM Mono', monospace", color: "rgba(232,234,240,0.7)" } }, `€${d.value}`)
                  )
                )
              )
            )
          )
        )
      ),

      // FAB
      React.createElement('button', { className: "fab", onClick: () => setShowForm(true) }, "+"),

      // Bottom nav
      React.createElement('div', { style: { position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 430, background: "rgba(10,14,26,0.96)", borderTop: "1px solid rgba(255,255,255,0.08)", padding: "10px 0 28px", display: "flex" } },
        [["dashboard", "📊", "Dashboard"], ["transactions", "📋", "Movimenti"], ["charts", "📈", "Grafici"]].map(([key, icon, label]) =>
          React.createElement('button', {
            key,
            onClick: () => setTab(key),
            style: { flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, background: "none", border: "none", cursor: "pointer", opacity: tab === key ? 1 : 0.4 }
          },
            React.createElement('span', { style: { fontSize: 20 } }, icon),
            React.createElement('span', { style: { fontSize: 10, fontWeight: 600, color: tab === key ? "#63B3ED" : "rgba(232,234,240,0.6)", letterSpacing: "0.03em", fontFamily: "'DM Sans', sans-serif" } }, label)
          )
        )
      ),

      // Modal
      showForm && React.createElement('div', { className: "modal-overlay", onClick: (e) => e.target === e.currentTarget && setShowForm(false) },
        React.createElement('div', { className: "modal" },
          React.createElement('div', { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 } },
            React.createElement('h2', { style: { fontSize: 18, fontWeight: 700 } }, "Nuova transazione"),
            React.createElement('button', { onClick: () => setShowForm(false), style: { background: "none", border: "none", cursor: "pointer", fontSize: 24, color: "rgba(232,234,240,0.4)" } }, "×")
          ),
          React.createElement('div', { className: "type-toggle", style: { marginBottom: 16 } },
            React.createElement('button', { className: "type-btn", onClick: () => setForm({ ...form, type: "expense", category: "" }), style: { color: form.type === "expense" ? "#fff" : "rgba(232,234,240,0.4)", background: form.type === "expense" ? "#FC8181" : "transparent" } }, "↓ Uscita"),
            React.createElement('button', { className: "type-btn", onClick: () => setForm({ ...form, type: "income", category: "" }), style: { color: form.type === "income" ? "#0A0E1A" : "rgba(232,234,240,0.4)", background: form.type === "income" ? "#4FD1C5" : "transparent" } }, "↑ Entrata")
          ),
          React.createElement('div', { style: { display: "flex", flexDirection: "column", gap: 12 } },
            React.createElement('input', { type: "number", placeholder: "Importo (€)", value: form.amount, onChange: e => setForm({ ...form, amount: e.target.value }) }),
            React.createElement('select', { value: form.category, onChange: e => setForm({ ...form, category: e.target.value }) },
              React.createElement('option', { value: "" }, "Seleziona categoria"),
              (form.type === "expense" ? CATEGORIES_EXPENSE : CATEGORIES_INCOME).map(c =>
                React.createElement('option', { key: c, value: c }, c)
              )
            ),
            React.createElement('input', { type: "text", placeholder: "Nota (opzionale)", value: form.note, onChange: e => setForm({ ...form, note: e.target.value }) }),
            React.createElement('input', { type: "date", value: form.date, onChange: e => setForm({ ...form, date: e.target.value }) }),
            React.createElement('button', { className: "pill-btn", onClick: addTransaction, style: { padding: 14, fontSize: 16, color: "#0A0E1A", background: "linear-gradient(135deg, #63B3ED, #4FD1C5)", marginTop: 4 } }, "✓ Aggiungi")
          )
        )
      )
    )
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App));
